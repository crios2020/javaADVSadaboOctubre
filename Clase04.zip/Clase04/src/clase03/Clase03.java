package clase03;

public class Clase03 {

    public static void main(String[] args) {
        
        /*
            Protocolo IP
        
            Protocolo TCP
        
        
            Server                                  Client
            --------------                          --------------
            x=new SeverSocket(int port);            x=new Socket(String ip, int port);
            x.accept();
            --------------                          --------------
            InputStream         <-------------      OutputStream
            OutputStream        ------------->      InputStream
            --------------                          --------------
            x.close();                              x.close();
        
            BufferedOutputStream BufferedInputStream:   Stream de Buffers
            DataOutputStream DataInputStream:           Stream de tipo de datos primitivos.
            ObjectOutputStream ObjectInputStream:       Stream de objetos de java
  
        */
        
        
    }
    
}
