package x;

import clase05.Dias;

public class X {
    public static void main(String[] args) {
        System.out.println(Dias.JUEVES);

    }
}
