package clase05;
class Test {
    
}

class X1{}
class X2{}

interface I1{}
interface I2{}
interface I3{}

// JDK 5
public enum Dias{ LUNES,MARTES,MIÉRCOLES,JUEVES,VIERNES }
enum Turno { MAÑANA, MEDIODÍA, TARDE, NOCHE }
enum Estaciones { PRIMAVERA, VERANO, OTOÑO, INVIERNO}

// indentificadores
class _X{}
class ${}

//class #X{}
//class ?X{}
//class -X{}

//class 2X{}
class X2X{}

