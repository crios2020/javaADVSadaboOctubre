package clase05;
public class Cita {
    private String nombre;
    private Dias dia;                 
    private Turno turno;

    public Cita(String nombre, Dias dia, Turno turno) {
        this.nombre = nombre;
        this.dia = dia;
        this.turno = turno;
    }
    
}
